#!/bin/bash

rm /var/log/apache/ilserv.duckdns.org.log
touch /var/log/apache/ilserv.duckdns.org.log
