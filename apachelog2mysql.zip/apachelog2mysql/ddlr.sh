#!/bin/bash

rm /var/log/apache/ilserv.duckdns.org.log
systemctl restart apache2
