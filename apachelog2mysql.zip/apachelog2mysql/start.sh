#!/bin/bash

sleep 10
curl https://ilserv.duckdns.org
sleep 100
python3 /usr/share/apachelog2mysql/main.py
